#ifndef __wasilibc_use_wasip2
#define __wasilibc_use_wasip2
#endif
