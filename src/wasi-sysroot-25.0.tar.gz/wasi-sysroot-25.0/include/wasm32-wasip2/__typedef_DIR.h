#ifndef __wasilibc___typedef_DIR_h
#define __wasilibc___typedef_DIR_h

typedef struct _DIR DIR;

#endif
